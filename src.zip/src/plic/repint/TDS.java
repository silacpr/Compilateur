package plic.repint;
import java.util.HashMap;
import java.util.Map;
public class TDS {
    private static TDS instance = null;
    private Map<Entree, Symbole> table;
    private int cptDepl;
    public TDS() {
        this.table = new HashMap<>();
        this.cptDepl = 0;
    }
    public static TDS getInstance() {
        if (instance == null) {
            instance = new TDS();
        }
        return instance;
    }
    public void ajouter(Entree e, Symbole s) throws DoubleDeclaration {
        if (table.containsKey(e)) throw new DoubleDeclaration("Double déclaration : "+e.getIdf());
        table.put(e, new Symbole(s.getType(), cptDepl * -4));
        cptDepl++;
    }
    public Symbole identifier(Entree e) {
        return this.table.get(e);
    }
    public boolean idfexiste(Entree e){
        return this.table.containsKey(e);
    }
}
