package plic.repint;

public class Acces {
}
