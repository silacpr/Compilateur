package plic.repint;

public abstract class Instruction {
    public abstract String toString();
}