package plic.repint;

public abstract class Expression {

    public abstract String getType();

    public abstract String toMips();


}
