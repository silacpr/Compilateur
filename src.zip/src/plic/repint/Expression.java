package plic.repint;

public abstract class Expression {
    public abstract String toString();
}
