package plic.repint;

public abstract class Symbole {

    public abstract int getDeplacement();

    public abstract String getType();

}
